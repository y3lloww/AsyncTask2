package com.example.sortingsimulationapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class SortingView extends View {
    private int[] array;
    private Paint paint;

    public SortingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(Color.BLUE);
    }

    public void setArray(int[] array) {
        this.array = array;
        invalidate();  // Odśwież widok po każdej zmianie danych
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (array == null || array.length == 0) return;

        int width = getWidth();
        int height = getHeight();
        int barWidth = width / array.length;

        // Zmienna maksymalna wartość w tablicy do skalowania wysokości słupków
        int maxValue = Integer.MIN_VALUE;
        for (int value : array) {
            if (value > maxValue) maxValue = value;
        }

        // Rysowanie każdego słupka
        for (int i = 0; i < array.length; i++) {
            int scaledHeight = (int) (((float) array[i] / maxValue) * height);
            int left = i * barWidth;
            int top = height - scaledHeight;
            int right = left + barWidth;
            int bottom = height;

            paint.setColor(Color.BLUE); // Możesz zmieniać kolor tutaj, aby dodać animację
            canvas.drawRect(left, top, right, bottom, paint);
        }
    }
}

package com.example.sortingsimulationapp;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumberOfElements;
    private Button buttonStartSorting;
    private ProgressBar progressBar;
    private SortingView sortingView;
    private ExecutorService executorService;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumberOfElements = findViewById(R.id.editTextNumberOfElements);
        buttonStartSorting = findViewById(R.id.buttonStartSorting);
        progressBar = findViewById(R.id.progressBar);
        sortingView = findViewById(R.id.sortingView);

        executorService = Executors.newSingleThreadExecutor();

        buttonStartSorting.setOnClickListener(view -> startSorting());
    }

    private void startSorting() {
        String inputText = editTextNumberOfElements.getText().toString();
        int numElements;

        try {
            numElements = Integer.parseInt(inputText);
            if (numElements <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid positive number", Toast.LENGTH_SHORT).show();
            return;
        }

        int[] array = generateRandomArray(numElements);

        progressBar.setMax(numElements);
        progressBar.setProgress(0);
        progressBar.setVisibility(ProgressBar.VISIBLE);

        sortingView.setArray(array); // Wyświetl początkowy stan tablicy

        executorService.execute(() -> bubbleSort(array));
    }

    private int[] generateRandomArray(int size) {
        int[] array = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(size);
        }
        return array;
    }

    private void bubbleSort(int[] array) {
        int n = array.length;
        long totalTime = 500;
        long delay = totalTime / (n * (n - 1) / 2); // opóźnienie dla każdej iteracji

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }

                int progress = i;
                handler.post(() -> {
                    progressBar.setProgress(progress);
                    sortingView.setArray(array); // Aktualizuj widok wykresu
                });

                try {
                    Thread.sleep(delay); // Dodaj opóźnienie, aby wydłużyć czas sortowania
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        handler.post(() -> {
            progressBar.setVisibility(ProgressBar.GONE);
            Toast.makeText(MainActivity.this, "Sorting Completed", Toast.LENGTH_SHORT).show();
        });
    }
}
